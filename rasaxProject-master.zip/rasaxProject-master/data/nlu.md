## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:GET_BOOKING_INFO
- when i will get booking confirmation
- is my booking confirmed
- can you tell me the status of my booking
- I want to check about my booking

## intent:BOOKING_ID
- ks54kg3245
- ks54kg4564
- ks54kg3424
- ks54kg7765
